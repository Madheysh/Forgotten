gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.idToCallbackMap = new Map();
gdjs.Untitled_32sceneCode.GDFlooringMapObjects1= [];
gdjs.Untitled_32sceneCode.GDFlooringMapObjects2= [];
gdjs.Untitled_32sceneCode.GDFlooringMapObjects3= [];
gdjs.Untitled_32sceneCode.GDPink_9595HouseObjects1= [];
gdjs.Untitled_32sceneCode.GDPink_9595HouseObjects2= [];
gdjs.Untitled_32sceneCode.GDPink_9595HouseObjects3= [];
gdjs.Untitled_32sceneCode.GDTeal_9595HomeObjects1= [];
gdjs.Untitled_32sceneCode.GDTeal_9595HomeObjects2= [];
gdjs.Untitled_32sceneCode.GDTeal_9595HomeObjects3= [];
gdjs.Untitled_32sceneCode.GDCream_9595HomeObjects1= [];
gdjs.Untitled_32sceneCode.GDCream_9595HomeObjects2= [];
gdjs.Untitled_32sceneCode.GDCream_9595HomeObjects3= [];
gdjs.Untitled_32sceneCode.GDMainCharacterObjects1= [];
gdjs.Untitled_32sceneCode.GDMainCharacterObjects2= [];
gdjs.Untitled_32sceneCode.GDMainCharacterObjects3= [];
gdjs.Untitled_32sceneCode.GDMainHomeObjects1= [];
gdjs.Untitled_32sceneCode.GDMainHomeObjects2= [];
gdjs.Untitled_32sceneCode.GDMainHomeObjects3= [];
gdjs.Untitled_32sceneCode.GDGrey_9595HomeObjects1= [];
gdjs.Untitled_32sceneCode.GDGrey_9595HomeObjects2= [];
gdjs.Untitled_32sceneCode.GDGrey_9595HomeObjects3= [];
gdjs.Untitled_32sceneCode.GDGreen_9595HomeObjects1= [];
gdjs.Untitled_32sceneCode.GDGreen_9595HomeObjects2= [];
gdjs.Untitled_32sceneCode.GDGreen_9595HomeObjects3= [];
gdjs.Untitled_32sceneCode.GDStreetObjectsObjects1= [];
gdjs.Untitled_32sceneCode.GDStreetObjectsObjects2= [];
gdjs.Untitled_32sceneCode.GDStreetObjectsObjects3= [];
gdjs.Untitled_32sceneCode.GDCOFEESHOPObjects1= [];
gdjs.Untitled_32sceneCode.GDCOFEESHOPObjects2= [];
gdjs.Untitled_32sceneCode.GDCOFEESHOPObjects3= [];
gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects1= [];
gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects2= [];
gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects3= [];
gdjs.Untitled_32sceneCode.GDHomefloorObjects1= [];
gdjs.Untitled_32sceneCode.GDHomefloorObjects2= [];
gdjs.Untitled_32sceneCode.GDHomefloorObjects3= [];
gdjs.Untitled_32sceneCode.GDNewTileMapObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTileMapObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTileMapObjects3= [];
gdjs.Untitled_32sceneCode.GDFURNITURE_9595HOUSEObjects1= [];
gdjs.Untitled_32sceneCode.GDFURNITURE_9595HOUSEObjects2= [];
gdjs.Untitled_32sceneCode.GDFURNITURE_9595HOUSEObjects3= [];
gdjs.Untitled_32sceneCode.GDhOUSEMINIDETAILSObjects1= [];
gdjs.Untitled_32sceneCode.GDhOUSEMINIDETAILSObjects2= [];
gdjs.Untitled_32sceneCode.GDhOUSEMINIDETAILSObjects3= [];
gdjs.Untitled_32sceneCode.GDNewSprite3Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite3Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite3Objects3= [];
gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects1= [];
gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects2= [];
gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects3= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects3= [];
gdjs.Untitled_32sceneCode.GDhospitalObjects1= [];
gdjs.Untitled_32sceneCode.GDhospitalObjects2= [];
gdjs.Untitled_32sceneCode.GDhospitalObjects3= [];
gdjs.Untitled_32sceneCode.GDhotelObjects1= [];
gdjs.Untitled_32sceneCode.GDhotelObjects2= [];
gdjs.Untitled_32sceneCode.GDhotelObjects3= [];
gdjs.Untitled_32sceneCode.GDroadsideObjects1= [];
gdjs.Untitled_32sceneCode.GDroadsideObjects2= [];
gdjs.Untitled_32sceneCode.GDroadsideObjects3= [];
gdjs.Untitled_32sceneCode.GDburgershopObjects1= [];
gdjs.Untitled_32sceneCode.GDburgershopObjects2= [];
gdjs.Untitled_32sceneCode.GDburgershopObjects3= [];
gdjs.Untitled_32sceneCode.GDchurchObjects1= [];
gdjs.Untitled_32sceneCode.GDchurchObjects2= [];
gdjs.Untitled_32sceneCode.GDchurchObjects3= [];
gdjs.Untitled_32sceneCode.GDGroceryObjects1= [];
gdjs.Untitled_32sceneCode.GDGroceryObjects2= [];
gdjs.Untitled_32sceneCode.GDGroceryObjects3= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects3= [];
gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects1= [];
gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects2= [];
gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects3= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects3= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects3= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects3= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects3= [];
gdjs.Untitled_32sceneCode.GDbenchObjects1= [];
gdjs.Untitled_32sceneCode.GDbenchObjects2= [];
gdjs.Untitled_32sceneCode.GDbenchObjects3= [];
gdjs.Untitled_32sceneCode.GDround_9595coffe_9595tableObjects1= [];
gdjs.Untitled_32sceneCode.GDround_9595coffe_9595tableObjects2= [];
gdjs.Untitled_32sceneCode.GDround_9595coffe_9595tableObjects3= [];
gdjs.Untitled_32sceneCode.GDCounter_95951Objects1= [];
gdjs.Untitled_32sceneCode.GDCounter_95951Objects2= [];
gdjs.Untitled_32sceneCode.GDCounter_95951Objects3= [];
gdjs.Untitled_32sceneCode.GDNewSprite4Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite4Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite4Objects3= [];
gdjs.Untitled_32sceneCode.GDNewSprite5Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite5Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite5Objects3= [];
gdjs.Untitled_32sceneCode.GDEntercoffeeObjects1= [];
gdjs.Untitled_32sceneCode.GDEntercoffeeObjects2= [];
gdjs.Untitled_32sceneCode.GDEntercoffeeObjects3= [];
gdjs.Untitled_32sceneCode.GDExitcoffeeObjects1= [];
gdjs.Untitled_32sceneCode.GDExitcoffeeObjects2= [];
gdjs.Untitled_32sceneCode.GDExitcoffeeObjects3= [];
gdjs.Untitled_32sceneCode.GDbarrierObjects1= [];
gdjs.Untitled_32sceneCode.GDbarrierObjects2= [];
gdjs.Untitled_32sceneCode.GDbarrierObjects3= [];
gdjs.Untitled_32sceneCode.GDLowPoly3DHeartObjects1= [];
gdjs.Untitled_32sceneCode.GDLowPoly3DHeartObjects2= [];
gdjs.Untitled_32sceneCode.GDLowPoly3DHeartObjects3= [];
gdjs.Untitled_32sceneCode.GDNewSprite6Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite6Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite6Objects3= [];
gdjs.Untitled_32sceneCode.GDTalkdogObjects1= [];
gdjs.Untitled_32sceneCode.GDTalkdogObjects2= [];
gdjs.Untitled_32sceneCode.GDTalkdogObjects3= [];
gdjs.Untitled_32sceneCode.GDNewSprite7Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite7Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite7Objects3= [];
gdjs.Untitled_32sceneCode.GDTalkBasketballObjects1= [];
gdjs.Untitled_32sceneCode.GDTalkBasketballObjects2= [];
gdjs.Untitled_32sceneCode.GDTalkBasketballObjects3= [];
gdjs.Untitled_32sceneCode.GDNewSprite8Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite8Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite8Objects3= [];
gdjs.Untitled_32sceneCode.GDtalkcofeeObjects1= [];
gdjs.Untitled_32sceneCode.GDtalkcofeeObjects2= [];
gdjs.Untitled_32sceneCode.GDtalkcofeeObjects3= [];
gdjs.Untitled_32sceneCode.GDNewSprite9Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite9Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite9Objects3= [];
gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1= [];
gdjs.Untitled_32sceneCode.GDcoffeeboxObjects2= [];
gdjs.Untitled_32sceneCode.GDcoffeeboxObjects3= [];
gdjs.Untitled_32sceneCode.GDCoffeetextObjects1= [];
gdjs.Untitled_32sceneCode.GDCoffeetextObjects2= [];
gdjs.Untitled_32sceneCode.GDCoffeetextObjects3= [];
gdjs.Untitled_32sceneCode.GDBbboxObjects1= [];
gdjs.Untitled_32sceneCode.GDBbboxObjects2= [];
gdjs.Untitled_32sceneCode.GDBbboxObjects3= [];
gdjs.Untitled_32sceneCode.GDbbtextObjects1= [];
gdjs.Untitled_32sceneCode.GDbbtextObjects2= [];
gdjs.Untitled_32sceneCode.GDbbtextObjects3= [];
gdjs.Untitled_32sceneCode.GDdogboxObjects1= [];
gdjs.Untitled_32sceneCode.GDdogboxObjects2= [];
gdjs.Untitled_32sceneCode.GDdogboxObjects3= [];
gdjs.Untitled_32sceneCode.GDdogtalkObjects1= [];
gdjs.Untitled_32sceneCode.GDdogtalkObjects2= [];
gdjs.Untitled_32sceneCode.GDdogtalkObjects3= [];
gdjs.Untitled_32sceneCode.GDgrandboxObjects1= [];
gdjs.Untitled_32sceneCode.GDgrandboxObjects2= [];
gdjs.Untitled_32sceneCode.GDgrandboxObjects3= [];
gdjs.Untitled_32sceneCode.GDgrandbox2Objects1= [];
gdjs.Untitled_32sceneCode.GDgrandbox2Objects2= [];
gdjs.Untitled_32sceneCode.GDgrandbox2Objects3= [];
gdjs.Untitled_32sceneCode.GDtalkgrandObjects1= [];
gdjs.Untitled_32sceneCode.GDtalkgrandObjects2= [];
gdjs.Untitled_32sceneCode.GDtalkgrandObjects3= [];
gdjs.Untitled_32sceneCode.GDintroObjects1= [];
gdjs.Untitled_32sceneCode.GDintroObjects2= [];
gdjs.Untitled_32sceneCode.GDintroObjects3= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPink_95959595HouseObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDTeal_95959595HomeObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDCream_95959595HomeObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDMainHomeObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDGrey_95959595HomeObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDGreen_95959595HomeObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDStreetObjectsObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDCOFEESHOPObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDFURNITURE_95959595HOUSEObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDhospitalObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDchurchObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDburgershopObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDGroceryObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDhotelObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDbenchObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDround_95959595coffe_95959595tableObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDCounter_959595951Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite4Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite5Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"Pink_House": gdjs.Untitled_32sceneCode.GDPink_9595HouseObjects1, "Teal_Home": gdjs.Untitled_32sceneCode.GDTeal_9595HomeObjects1, "Cream_Home": gdjs.Untitled_32sceneCode.GDCream_9595HomeObjects1, "MainHome": gdjs.Untitled_32sceneCode.GDMainHomeObjects1, "Grey_Home": gdjs.Untitled_32sceneCode.GDGrey_9595HomeObjects1, "Green_Home": gdjs.Untitled_32sceneCode.GDGreen_9595HomeObjects1, "StreetObjects": gdjs.Untitled_32sceneCode.GDStreetObjectsObjects1, "COFEESHOP": gdjs.Untitled_32sceneCode.GDCOFEESHOPObjects1, "FURNITURE_HOUSE": gdjs.Untitled_32sceneCode.GDFURNITURE_9595HOUSEObjects1, "hospital": gdjs.Untitled_32sceneCode.GDhospitalObjects1, "church": gdjs.Untitled_32sceneCode.GDchurchObjects1, "burgershop": gdjs.Untitled_32sceneCode.GDburgershopObjects1, "Grocery": gdjs.Untitled_32sceneCode.GDGroceryObjects1, "hotel": gdjs.Untitled_32sceneCode.GDhotelObjects1, "bench": gdjs.Untitled_32sceneCode.GDbenchObjects1, "round_coffe_table": gdjs.Untitled_32sceneCode.GDround_9595coffe_9595tableObjects1, "Counter_1": gdjs.Untitled_32sceneCode.GDCounter_95951Objects1, "NewSprite4": gdjs.Untitled_32sceneCode.GDNewSprite4Objects1, "NewSprite5": gdjs.Untitled_32sceneCode.GDNewSprite5Objects1, "barrier": gdjs.Untitled_32sceneCode.GDbarrierObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDMainCharacterObjects1, gdjs.Untitled_32sceneCode.GDMainCharacterObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[i].getY() > gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + 352 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[k] = gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + 704, "", 0);
}
}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDMainCharacterObjects1, gdjs.Untitled_32sceneCode.GDMainCharacterObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[i].getY() < gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - 352 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[k] = gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) - 704, "", 0);
}
}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDMainCharacterObjects1, gdjs.Untitled_32sceneCode.GDMainCharacterObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[i].getX() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + 512 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[k] = gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + 1024, "", 0);
}
}

}


{

/* Reuse gdjs.Untitled_32sceneCode.GDMainCharacterObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - 512 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[k] = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - 1024, "", 0);
}
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects1Objects = Hashtable.newFrom({"MainCharacter": gdjs.Untitled_32sceneCode.GDMainCharacterObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHOUSEENTERObjects1Objects = Hashtable.newFrom({"HOUSEENTER": gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects1Objects = Hashtable.newFrom({"MainCharacter": gdjs.Untitled_32sceneCode.GDMainCharacterObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHOUSEEXITObjects1Objects = Hashtable.newFrom({"HOUSEEXIT": gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.Untitled_32sceneCode.GDNewSprite2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects1Objects = Hashtable.newFrom({"MainCharacter": gdjs.Untitled_32sceneCode.GDMainCharacterObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.Untitled_32sceneCode.GDNewSprite2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects1Objects = Hashtable.newFrom({"MainCharacter": gdjs.Untitled_32sceneCode.GDMainCharacterObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEntercoffeeObjects1Objects = Hashtable.newFrom({"Entercoffee": gdjs.Untitled_32sceneCode.GDEntercoffeeObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects1Objects = Hashtable.newFrom({"MainCharacter": gdjs.Untitled_32sceneCode.GDMainCharacterObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDExitcoffeeObjects1Objects = Hashtable.newFrom({"Exitcoffee": gdjs.Untitled_32sceneCode.GDExitcoffeeObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects2Objects = Hashtable.newFrom({"MainCharacter": gdjs.Untitled_32sceneCode.GDMainCharacterObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDtalkcofeeObjects2Objects = Hashtable.newFrom({"talkcofee": gdjs.Untitled_32sceneCode.GDtalkcofeeObjects2});
gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("talkcofee"), gdjs.Untitled_32sceneCode.GDtalkcofeeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDtalkcofeeObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(150553812);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Coffeetext"), gdjs.Untitled_32sceneCode.GDCoffeetextObjects2);
/* Reuse gdjs.Untitled_32sceneCode.GDMainCharacterObjects2 */
gdjs.copyArray(runtimeScene.getObjects("coffeebox"), gdjs.Untitled_32sceneCode.GDcoffeeboxObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcoffeeboxObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcoffeeboxObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCoffeetextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCoffeetextObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[i].activateBehavior("TopDownMovement", false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCoffeetextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCoffeetextObjects2[i].getBehavior("AutoTyping").RestartFromBeginning(null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("coffeebox"), gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1[k] = gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Coffeetext"), gdjs.Untitled_32sceneCode.GDCoffeetextObjects1);
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCoffeetextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCoffeetextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].activateBehavior("TopDownMovement", true);
}
}
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects2Objects = Hashtable.newFrom({"MainCharacter": gdjs.Untitled_32sceneCode.GDMainCharacterObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDTalkBasketballObjects2Objects = Hashtable.newFrom({"TalkBasketball": gdjs.Untitled_32sceneCode.GDTalkBasketballObjects2});
gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("TalkBasketball"), gdjs.Untitled_32sceneCode.GDTalkBasketballObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDTalkBasketballObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(150159204);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bbbox"), gdjs.Untitled_32sceneCode.GDBbboxObjects2);
/* Reuse gdjs.Untitled_32sceneCode.GDMainCharacterObjects2 */
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.Untitled_32sceneCode.GDNewSprite2Objects2);
gdjs.copyArray(runtimeScene.getObjects("basketballthrower"), gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects2);
gdjs.copyArray(runtimeScene.getObjects("bbtext"), gdjs.Untitled_32sceneCode.GDbbtextObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBbboxObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBbboxObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbbtextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbbtextObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[i].activateBehavior("TopDownMovement", false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbbtextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbbtextObjects2[i].getBehavior("AutoTyping").RestartFromBeginning(null);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSprite2Objects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects2[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bbbox"), gdjs.Untitled_32sceneCode.GDBbboxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBbboxObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBbboxObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBbboxObjects1[k] = gdjs.Untitled_32sceneCode.GDBbboxObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBbboxObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBbboxObjects1 */
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("bbtext"), gdjs.Untitled_32sceneCode.GDbbtextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBbboxObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBbboxObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbbtextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbbtextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].activateBehavior("TopDownMovement", true);
}
}
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects2Objects = Hashtable.newFrom({"MainCharacter": gdjs.Untitled_32sceneCode.GDMainCharacterObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDTalkdogObjects2Objects = Hashtable.newFrom({"Talkdog": gdjs.Untitled_32sceneCode.GDTalkdogObjects2});
gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Talkdog"), gdjs.Untitled_32sceneCode.GDTalkdogObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDTalkdogObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(146305060);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDMainCharacterObjects2 */
gdjs.copyArray(runtimeScene.getObjects("dogbox"), gdjs.Untitled_32sceneCode.GDdogboxObjects2);
gdjs.copyArray(runtimeScene.getObjects("dogtalk"), gdjs.Untitled_32sceneCode.GDdogtalkObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdogboxObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdogboxObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdogtalkObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdogtalkObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[i].activateBehavior("TopDownMovement", false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdogtalkObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdogtalkObjects2[i].getBehavior("AutoTyping").RestartFromBeginning(null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dogbox"), gdjs.Untitled_32sceneCode.GDdogboxObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDdogboxObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDdogboxObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDdogboxObjects2[k] = gdjs.Untitled_32sceneCode.GDdogboxObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDdogboxObjects2.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects2);
/* Reuse gdjs.Untitled_32sceneCode.GDdogboxObjects2 */
gdjs.copyArray(runtimeScene.getObjects("dogtalk"), gdjs.Untitled_32sceneCode.GDdogtalkObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdogboxObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdogboxObjects2[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdogtalkObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdogtalkObjects2[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[i].activateBehavior("TopDownMovement", true);
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects2Objects = Hashtable.newFrom({"MainCharacter": gdjs.Untitled_32sceneCode.GDMainCharacterObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDtalkgrandObjects2Objects = Hashtable.newFrom({"talkgrand": gdjs.Untitled_32sceneCode.GDtalkgrandObjects2});
gdjs.Untitled_32sceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("talkgrand"), gdjs.Untitled_32sceneCode.GDtalkgrandObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDtalkgrandObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(149932516);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDMainCharacterObjects2 */
gdjs.copyArray(runtimeScene.getObjects("grandbox"), gdjs.Untitled_32sceneCode.GDgrandboxObjects2);
gdjs.copyArray(runtimeScene.getObjects("grandbox2"), gdjs.Untitled_32sceneCode.GDgrandbox2Objects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgrandboxObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgrandboxObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgrandbox2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgrandbox2Objects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects2[i].activateBehavior("TopDownMovement", false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgrandbox2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgrandbox2Objects2[i].getBehavior("AutoTyping").RestartFromBeginning(null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("grandbox"), gdjs.Untitled_32sceneCode.GDgrandboxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDgrandboxObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDgrandboxObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDgrandboxObjects1[k] = gdjs.Untitled_32sceneCode.GDgrandboxObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDgrandboxObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDgrandboxObjects1 */
gdjs.copyArray(runtimeScene.getObjects("grandbox2"), gdjs.Untitled_32sceneCode.GDgrandbox2Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgrandboxObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgrandboxObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgrandbox2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgrandbox2Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].activateBehavior("TopDownMovement", true);
}
}
}

}


};gdjs.Untitled_32sceneCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bbbox"), gdjs.Untitled_32sceneCode.GDBbboxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Coffeetext"), gdjs.Untitled_32sceneCode.GDCoffeetextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Entercoffee"), gdjs.Untitled_32sceneCode.GDEntercoffeeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Exitcoffee"), gdjs.Untitled_32sceneCode.GDExitcoffeeObjects1);
gdjs.copyArray(runtimeScene.getObjects("HOUSEENTER"), gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects1);
gdjs.copyArray(runtimeScene.getObjects("HOUSEEXIT"), gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite8"), gdjs.Untitled_32sceneCode.GDNewSprite8Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite9"), gdjs.Untitled_32sceneCode.GDNewSprite9Objects1);
gdjs.copyArray(runtimeScene.getObjects("TalkBasketball"), gdjs.Untitled_32sceneCode.GDTalkBasketballObjects1);
gdjs.copyArray(runtimeScene.getObjects("Talkdog"), gdjs.Untitled_32sceneCode.GDTalkdogObjects1);
gdjs.copyArray(runtimeScene.getObjects("bbtext"), gdjs.Untitled_32sceneCode.GDbbtextObjects1);
gdjs.copyArray(runtimeScene.getObjects("coffeebox"), gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1);
gdjs.copyArray(runtimeScene.getObjects("dogbox"), gdjs.Untitled_32sceneCode.GDdogboxObjects1);
gdjs.copyArray(runtimeScene.getObjects("dogtalk"), gdjs.Untitled_32sceneCode.GDdogtalkObjects1);
gdjs.copyArray(runtimeScene.getObjects("grandbox"), gdjs.Untitled_32sceneCode.GDgrandboxObjects1);
gdjs.copyArray(runtimeScene.getObjects("grandbox2"), gdjs.Untitled_32sceneCode.GDgrandbox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("intro"), gdjs.Untitled_32sceneCode.GDintroObjects1);
gdjs.copyArray(runtimeScene.getObjects("talkcofee"), gdjs.Untitled_32sceneCode.GDtalkcofeeObjects1);
gdjs.copyArray(runtimeScene.getObjects("talkgrand"), gdjs.Untitled_32sceneCode.GDtalkgrandObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEntercoffeeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEntercoffeeObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDExitcoffeeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDExitcoffeeObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDtalkcofeeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDtalkcofeeObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTalkBasketballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTalkBasketballObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTalkdogObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTalkdogObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCoffeetextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCoffeetextObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdogtalkObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdogtalkObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgrandbox2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgrandbox2Objects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbbtextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbbtextObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDdogboxObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDdogboxObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBbboxObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBbboxObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgrandboxObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgrandboxObjects1[i].hide();
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDtalkgrandObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDtalkgrandObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSprite8Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSprite8Objects1[i].getBehavior("Scale").setScale(1.5);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSprite9Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSprite9Objects1[i].getBehavior("Scale").setScale(1.5);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDintroObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDintroObjects1[i].play();
}
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, -512, "", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, 1056, "", 0);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("intro"), gdjs.Untitled_32sceneCode.GDintroObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDintroObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDintroObjects1[i].isEnded() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDintroObjects1[k] = gdjs.Untitled_32sceneCode.GDintroObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDintroObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDintroObjects1 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, 512, "", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, 352, "", 0);
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDintroObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDintroObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("COFEESHOP"), gdjs.Untitled_32sceneCode.GDCOFEESHOPObjects1);
gdjs.copyArray(runtimeScene.getObjects("Counter_1"), gdjs.Untitled_32sceneCode.GDCounter_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Cream_Home"), gdjs.Untitled_32sceneCode.GDCream_9595HomeObjects1);
gdjs.copyArray(runtimeScene.getObjects("FURNITURE_HOUSE"), gdjs.Untitled_32sceneCode.GDFURNITURE_9595HOUSEObjects1);
gdjs.copyArray(runtimeScene.getObjects("Green_Home"), gdjs.Untitled_32sceneCode.GDGreen_9595HomeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Grey_Home"), gdjs.Untitled_32sceneCode.GDGrey_9595HomeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Grocery"), gdjs.Untitled_32sceneCode.GDGroceryObjects1);
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("MainHome"), gdjs.Untitled_32sceneCode.GDMainHomeObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.Untitled_32sceneCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite5"), gdjs.Untitled_32sceneCode.GDNewSprite5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Pink_House"), gdjs.Untitled_32sceneCode.GDPink_9595HouseObjects1);
gdjs.copyArray(runtimeScene.getObjects("StreetObjects"), gdjs.Untitled_32sceneCode.GDStreetObjectsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Teal_Home"), gdjs.Untitled_32sceneCode.GDTeal_9595HomeObjects1);
gdjs.copyArray(runtimeScene.getObjects("barrier"), gdjs.Untitled_32sceneCode.GDbarrierObjects1);
gdjs.copyArray(runtimeScene.getObjects("bench"), gdjs.Untitled_32sceneCode.GDbenchObjects1);
gdjs.copyArray(runtimeScene.getObjects("burgershop"), gdjs.Untitled_32sceneCode.GDburgershopObjects1);
gdjs.copyArray(runtimeScene.getObjects("church"), gdjs.Untitled_32sceneCode.GDchurchObjects1);
gdjs.copyArray(runtimeScene.getObjects("hospital"), gdjs.Untitled_32sceneCode.GDhospitalObjects1);
gdjs.copyArray(runtimeScene.getObjects("hotel"), gdjs.Untitled_32sceneCode.GDhotelObjects1);
gdjs.copyArray(runtimeScene.getObjects("round_coffe_table"), gdjs.Untitled_32sceneCode.GDround_9595coffe_9595tableObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPink_95959595HouseObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDTeal_95959595HomeObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDCream_95959595HomeObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDMainHomeObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDGrey_95959595HomeObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDGreen_95959595HomeObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDStreetObjectsObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDCOFEESHOPObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDFURNITURE_95959595HOUSEObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDhospitalObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDchurchObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDburgershopObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDGroceryObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDhotelObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDbenchObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDround_95959595coffe_95959595tableObjects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDCounter_959595951Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite4Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite5Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDbarrierObjects1Objects, true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length;i<l;++i) {
    if ( !(gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].getBehavior("InOnScreen").IsOnScreen(0, null)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[k] = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) == 512;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) == -352;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].getBehavior("Scale").setScale(1.5);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HOUSEENTER"), gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects1);
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHOUSEENTERObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23814932);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MainHome"), gdjs.Untitled_32sceneCode.GDMainHomeObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainHomeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainHomeObjects1[i].getBehavior("Animation").setAnimationName("DoorOpen");
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "HOUSEENTER");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "HOUSEENTER") >= 0.5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].setPosition(512,-200);
}
}
{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "HOUSEENTER");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HOUSEEXIT"), gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects1);
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHOUSEEXITObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDMainCharacterObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].setPosition(528,248);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].getBehavior("Scale").setScale(gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].getBehavior("Scale").getScale() / (1.5));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) == -1536;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) == 352;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("basketballthrower"), gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects1);
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects1[i].getBehavior("FireBullet").Fire((gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects1[i].getPointX("")), (gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects1[i].getPointY("")), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite2Objects1Objects, 270, 160, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.Untitled_32sceneCode.GDNewSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDMainCharacterObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].addForce(128, 128, 0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Entercoffee"), gdjs.Untitled_32sceneCode.GDEntercoffeeObjects1);
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEntercoffeeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDMainCharacterObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].setPosition(-956,-94);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].getBehavior("Scale").setScale(1.5);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exitcoffee"), gdjs.Untitled_32sceneCode.GDExitcoffeeObjects1);
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMainCharacterObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDExitcoffeeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDMainCharacterObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].setPosition(-178,280);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].getBehavior("Scale").setScale(gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].getBehavior("Scale").getScale() / (1.5));
}
}
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MainCharacter"), gdjs.Untitled_32sceneCode.GDMainCharacterObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMainCharacterObjects1[i].getBehavior("Animation").setAnimationName(runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() + runtimeScene.getScene().getVariables().getFromIndex(6).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("Walk");
}
{runtimeScene.getScene().getVariables().getFromIndex(6).setString("Up");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("Walk");
}
{runtimeScene.getScene().getVariables().getFromIndex(6).setString("Down");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("Walk");
}
{runtimeScene.getScene().getVariables().getFromIndex(6).setString("Left");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("Walk");
}
{runtimeScene.getScene().getVariables().getFromIndex(6).setString("Right");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Down");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("Idle");
}
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDFlooringMapObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFlooringMapObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFlooringMapObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPink_9595HouseObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPink_9595HouseObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPink_9595HouseObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDTeal_9595HomeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTeal_9595HomeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTeal_9595HomeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDCream_9595HomeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCream_9595HomeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCream_9595HomeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDMainCharacterObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDMainHomeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMainHomeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDMainHomeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDGrey_9595HomeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGrey_9595HomeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGrey_9595HomeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDGreen_9595HomeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGreen_9595HomeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGreen_9595HomeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDStreetObjectsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStreetObjectsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStreetObjectsObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDCOFEESHOPObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCOFEESHOPObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCOFEESHOPObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHomefloorObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHomefloorObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHomefloorObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewTileMapObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTileMapObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTileMapObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDFURNITURE_9595HOUSEObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFURNITURE_9595HOUSEObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFURNITURE_9595HOUSEObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDhOUSEMINIDETAILSObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDhOUSEMINIDETAILSObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDhOUSEMINIDETAILSObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDhospitalObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDhospitalObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDhospitalObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDhotelObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDhotelObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDhotelObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDroadsideObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDroadsideObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDroadsideObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDburgershopObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDburgershopObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDburgershopObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDchurchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDchurchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDchurchObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDGroceryObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGroceryObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGroceryObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDbenchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbenchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbenchObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDround_9595coffe_9595tableObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDround_9595coffe_9595tableObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDround_9595coffe_9595tableObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDCounter_95951Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCounter_95951Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCounter_95951Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDEntercoffeeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDEntercoffeeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDEntercoffeeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDExitcoffeeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDExitcoffeeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDExitcoffeeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDbarrierObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbarrierObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbarrierObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDLowPoly3DHeartObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLowPoly3DHeartObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLowPoly3DHeartObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite6Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite6Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite6Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDTalkdogObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTalkdogObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTalkdogObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite7Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite7Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite7Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDTalkBasketballObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTalkBasketballObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTalkBasketballObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite8Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite8Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite8Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDtalkcofeeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtalkcofeeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtalkcofeeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite9Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite9Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite9Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDcoffeeboxObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDcoffeeboxObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDCoffeetextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCoffeetextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCoffeetextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBbboxObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBbboxObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBbboxObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDbbtextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbbtextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbbtextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDdogboxObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDdogboxObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDdogboxObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDdogtalkObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDdogtalkObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDdogtalkObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDgrandboxObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDgrandboxObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDgrandboxObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDgrandbox2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDgrandbox2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDgrandbox2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDtalkgrandObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtalkgrandObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtalkgrandObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDintroObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDintroObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDintroObjects3.length = 0;

gdjs.Untitled_32sceneCode.eventsList5(runtimeScene);
gdjs.Untitled_32sceneCode.GDFlooringMapObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFlooringMapObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFlooringMapObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPink_9595HouseObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPink_9595HouseObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPink_9595HouseObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDTeal_9595HomeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTeal_9595HomeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTeal_9595HomeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDCream_9595HomeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCream_9595HomeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCream_9595HomeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDMainCharacterObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMainCharacterObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDMainCharacterObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDMainHomeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMainHomeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDMainHomeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDGrey_9595HomeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGrey_9595HomeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGrey_9595HomeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDGreen_9595HomeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGreen_9595HomeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGreen_9595HomeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDStreetObjectsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStreetObjectsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStreetObjectsObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDCOFEESHOPObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCOFEESHOPObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCOFEESHOPObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEENTERObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHomefloorObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHomefloorObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHomefloorObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewTileMapObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTileMapObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTileMapObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDFURNITURE_9595HOUSEObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFURNITURE_9595HOUSEObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFURNITURE_9595HOUSEObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDhOUSEMINIDETAILSObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDhOUSEMINIDETAILSObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDhOUSEMINIDETAILSObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHOUSEEXITObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDhospitalObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDhospitalObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDhospitalObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDhotelObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDhotelObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDhotelObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDroadsideObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDroadsideObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDroadsideObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDburgershopObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDburgershopObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDburgershopObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDchurchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDchurchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDchurchObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDGroceryObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGroceryObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGroceryObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbasketballthrowerObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDbenchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbenchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbenchObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDround_9595coffe_9595tableObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDround_9595coffe_9595tableObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDround_9595coffe_9595tableObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDCounter_95951Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCounter_95951Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCounter_95951Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDEntercoffeeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDEntercoffeeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDEntercoffeeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDExitcoffeeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDExitcoffeeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDExitcoffeeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDbarrierObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbarrierObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbarrierObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDLowPoly3DHeartObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLowPoly3DHeartObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLowPoly3DHeartObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite6Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite6Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite6Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDTalkdogObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTalkdogObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTalkdogObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite7Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite7Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite7Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDTalkBasketballObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTalkBasketballObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTalkBasketballObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite8Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite8Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite8Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDtalkcofeeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtalkcofeeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtalkcofeeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite9Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite9Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite9Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDcoffeeboxObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDcoffeeboxObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDcoffeeboxObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDCoffeetextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCoffeetextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCoffeetextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBbboxObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBbboxObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBbboxObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDbbtextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbbtextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbbtextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDdogboxObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDdogboxObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDdogboxObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDdogtalkObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDdogtalkObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDdogtalkObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDgrandboxObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDgrandboxObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDgrandboxObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDgrandbox2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDgrandbox2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDgrandbox2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDtalkgrandObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtalkgrandObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtalkgrandObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDintroObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDintroObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDintroObjects3.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
